package ${PACKAGE_NAME};
#if ($NAME.indexOf('Controller') != -1)
    #set ($NAME = $NAME.substring(0,$NAME.indexOf('Controller')))
#end

#if ($NAME.indexOf('controller') != -1 )
    #set ($NAME = $NAME.substring(0,$NAME.indexOf('controller')))
#end

#set ($controllerName = ${StringUtils.capitalizeFirstLetter(${NAME})})
#set ($serviceName = ${StringUtils.capitalizeFirstLetter(${NAME})})

#if ($controllerName.indexOf('Controller') < 1)
    #set ($controllerName = $controllerName + 'Controller')
#end

#if ($serviceName.indexOf('Service') < 1)
    #set ($serviceName = $serviceName + 'Service')
#end

#set( $mapping = "$NAME.substring(0,1).toLowerCase()$NAME.substring(1)s" )
#if ($NAME.indexOf('Controller') < 1)
    #set ($NAME = $NAME + 'Controller')
#end
#set ($controllerName = ${StringUtils.capitalizeFirstLetter(${NAME})})
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/${mapping}")
public class $controllerName {
    private final ${serviceName} $serviceName.substring(0,1).toLowerCase()$serviceName.substring(1);
}