package ${PACKAGE_NAME};

#if ($NAME.indexOf('Service') != -1)
    #set ($NAME = $NAME.substring(0,$NAME.indexOf('Service')))
#end

#if ($NAME.indexOf('service') != -1)
    #set ($NAME = $NAME.substring(0,$NAME.indexOf('service')))
#end

#set ($serviceName = ${StringUtils.capitalizeFirstLetter(${NAME})})
#set ($repository =${StringUtils.capitalizeFirstLetter(${NAME})})
#if ($serviceName.indexOf('Service') < 1)
    #set ($serviceName = $serviceName + 'Service')
#end

#if ($repository.indexOf('Repository') < 1)
    #set ($repository = $repository + 'Repository')
#end

#if ($NAME.indexOf('ServiceImpl') < 1)
    #set ($NAME = $NAME + 'ServiceImpl')
#end
#set ($serviceImplName = ${StringUtils.capitalizeFirstLetter(${NAME})})

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class $serviceImplName implements $serviceName {
    private final ${repository} $repository.substring(0,1).toLowerCase()$repository.substring(1);
}