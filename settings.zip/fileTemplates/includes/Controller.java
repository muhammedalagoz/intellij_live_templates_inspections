@org.springframework.web.bind.annotation.RestController
class $entity$Controller {

    private $entity$Repository repository;

    public $entity$Controller($entity$Repository repository) {
        this.repository = repository;
    }

    @org.springframework.web.bind.annotation.GetMapping("/$uriMapping$")
    java.util.Collection<$entity$> list() {
        return repository.findAll();
    }
}