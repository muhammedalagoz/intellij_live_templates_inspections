package ${PACKAGE_NAME};

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ${StringUtils.capitalizeFirstLetter(${NAME})} {
}