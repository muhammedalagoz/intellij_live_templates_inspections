package ${PACKAGE_NAME};

import org.springframework.stereotype.Component;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class ${StringUtils.capitalizeFirstLetter(${NAME})} {

}