#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "") 
    package ${PACKAGE_NAME};
#end
#if ($NAME.indexOf('Service') < 1) 
    #set ($NAME = $NAME + 'Service')
#end

public interface ${StringUtils.capitalizeFirstLetter(${NAME})} {
}