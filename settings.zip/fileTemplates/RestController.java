package ${PACKAGE_NAME}.controller;

import ${PACKAGE_NAME}.service.${StringUtils.capitalizeFirstLetter(${NAME})}Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/${NAME}")
public class ${StringUtils.capitalizeFirstLetter(${NAME})}Controller {
    private final ${StringUtils.capitalizeFirstLetter(${NAME})}Service ${NAME}Service;
}