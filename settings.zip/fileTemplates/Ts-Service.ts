import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {PageQuery} from '../../shared/models/page-query';
import {Observable} from 'rxjs';
import {Page} from '../../shared/models/page';

@Injectable({
  providedIn: 'root'
})
export class ${StringUtils.capitalizeFirstLetter(${NAME})}Service {
#set($fc = $NAME.substring(0,1).toLowerCase())
#set($oc = $NAME.substring(1).toLowerCase())
#set( $variable = "$fc$oc")

  constructor(private http: HttpClient) {
  }

  public search${StringUtils.capitalizeFirstLetter(${NAME})}s(searchQuery: any, pageQuery: PageQuery): Observable<Page<any>> {
    const fromObject = {...searchQuery, ...pageQuery};
    const params = new HttpParams({fromObject});
    return this.http.get<Page<any>>('/api/${api}', {params});
  }

  public get${StringUtils.capitalizeFirstLetter(${NAME})}Detail(id: number): Observable<any> {
    return this.http.get<any>(`/api/${api}/\${id}`);
  }

  public save${StringUtils.capitalizeFirstLetter(${NAME})}($variable: any): Observable<void> {
    return this.http.post<any>('api/${api}', $variable);
  }

}