#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#set ($NAME = ${StringUtils.capitalizeFirstLetter(${NAME})})

#if ($NAME.indexOf('Repository') < 1) 
    #set ($NAME = $NAME + 'Repository') 
#end
#set ($index = $NAME.indexOf('Repository'))
#set ($ENTITY= $NAME.substring(0, $index))

import org.springframework.data.jpa.repository.JpaRepository;

public interface ${NAME} extends JpaRepository<$ENTITY, Long> {
}