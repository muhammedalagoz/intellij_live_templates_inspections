package ${PACKAGE_NAME};

import lombok.*;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
class ${StringUtils.capitalizeFirstLetter(${NAME})} {

    @Id
    @GeneratedValue
    private java.lang.Long id;

    private java.lang.String name;
}